import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Star, Clock, BarChart, ArrowRight, Lock, X, BookOpen, GraduationCap, PlayCircle, Play } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { PROGRAMS } from '../constants';
import { cn } from '../lib/utils';
import { auth, db, signInWithGoogle } from '../firebase';
import { collection, query, where, onSnapshot, doc, setDoc, Timestamp } from 'firebase/firestore';
import { Enrollment } from '../types';

export function Programs() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState('All');
  const [user, setUser] = useState(auth.currentUser);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [selectedProgramId, setSelectedProgramId] = useState<string | null>(null);

  const categories = ['All', 'Tech', 'Data', 'Marketing', 'Design', 'Business'];

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(collection(db, 'enrollments'), where('userId', '==', user.uid));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(docSnap => {
          const d = { id: docSnap.id, ...docSnap.data() } as Enrollment;
          const now = new Date();
          const due = new Date(d.dueDate);
          if (now > due && d.status === 'active') {
            setDoc(doc(db, 'enrollments', d.id), { ...d, status: 'locked' }, { merge: true });
            return { ...d, status: 'locked' };
          }
          return d;
        });
        setEnrollments(data);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const handleEnroll = async (programId: string) => {
    if (!user) {
      try {
        await signInWithGoogle();
      } catch (error) {
        console.error("Login failed", error);
        return;
      }
    }

    const existingEnrollment = enrollments.find(e => e.programId === programId);
    
    if (existingEnrollment) {
      if (existingEnrollment.status === 'locked') {
        setSelectedProgramId(programId);
        setShowPaymentModal(true);
      } else {
        setSelectedProgramId(programId);
        setShowDetailsModal(true);
      }
    } else {
      setSelectedProgramId(programId);
      setShowPaymentModal(true);
    }
  };

  const handleTryFree = (programId: string) => {
    setSelectedProgramId(programId);
    setShowDemoModal(true);
  };

  const selectedProgram = PROGRAMS.find(p => p.id === selectedProgramId);

  const [phoneNumber, setPhoneNumber] = useState('');
  const [isPaying, setIsPaying] = useState(false);

  const processPayment = async () => {
    if (!user || !selectedProgramId || !phoneNumber) return;

    setIsPaying(true);
    // Simulate M-Pesa STK Push delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    const enrollmentId = `${user.uid}_${selectedProgramId}`;
    const dueDate = new Timestamp(Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60, 0);

    await setDoc(doc(db, 'enrollments', enrollmentId), {
      id: enrollmentId,
      userId: user.uid,
      programId: selectedProgramId,
      status: 'active',
      progress: 0,
      completedModules: [],
      dueDate: dueDate.toDate().toISOString(),
      lastPaymentDate: new Date().toISOString()
    });

    setIsPaying(false);
    setShowPaymentModal(false);
    navigate(`/programs/${selectedProgramId}`);
  };

  const filteredPrograms = filter === 'All' 
    ? PROGRAMS 
    : PROGRAMS.filter(p => p.category === filter);

  return (
    <div className="min-h-screen bg-dark-bg pt-32 pb-20 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20 space-y-6">
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-sky-400 font-bold text-lg tracking-widest uppercase"
          >
            Kenflix Programs
          </motion.p>
          <motion.h1 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-bold text-white"
          >
            Our Programs
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-slate-400 max-w-2xl mx-auto text-lg"
          >
            Choose from a variety of world-class programs designed to help you master the skills needed for the digital economy.
          </motion.p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-16">
          {categories.map((cat, idx) => (
            <motion.button
              key={cat}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              onClick={() => setFilter(cat)}
              className={cn(
                "px-8 py-3 rounded-full text-sm font-bold transition-all border-2",
                filter === cat 
                  ? "bg-sky-500 text-white border-sky-500 shadow-xl shadow-sky-500/20 scale-105" 
                  : "bg-slate-900 text-slate-400 border-slate-800 hover:border-sky-500/30 hover:text-sky-400 shadow-sm"
              )}
            >
              {cat}
            </motion.button>
          ))}
        </div>

        {/* Program Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPrograms.map((program) => {
            const enrollment = enrollments.find(e => e.programId === program.id);
            const isLocked = enrollment?.status === 'locked';
            const isEnrolled = !!enrollment;

            return (
              <motion.div 
                key={program.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ y: -10 }}
                className="card-dark flex flex-col group"
              >
                <div className="h-64 overflow-hidden relative">
                  <img src={program.image} alt={program.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                  <div className="absolute top-6 left-6">
                    <span className="bg-sky-500 text-white text-[10px] font-bold px-4 py-1.5 rounded-full uppercase tracking-wider shadow-lg">
                      {program.category}
                    </span>
                  </div>
                  {isLocked && (
                    <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center">
                      <div className="text-center">
                        <Lock className="w-10 h-10 text-orange-500 mx-auto mb-2" />
                        <span className="text-white font-bold">Payment Due</span>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-8 flex-1 flex flex-col">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-4 h-4 text-sky-400" />
                    <span className="text-slate-400 text-sm font-medium">{program.duration}</span>
                  </div>
                  <h3 className="text-2xl font-display font-bold text-white mb-4 group-hover:text-sky-400 transition-colors">{program.title}</h3>
                  <p className="text-slate-400 text-sm line-clamp-3 mb-8 leading-relaxed">
                    {program.description}
                  </p>
                  
                  <div className="mt-auto pt-6 border-t border-slate-900 flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <button 
                        onClick={() => handleEnroll(program.id)}
                        className="text-sky-400 font-bold text-sm flex items-center gap-2 group/link hover:text-sky-300 transition-colors"
                      >
                        {isLocked ? 'Unlock Course' : isEnrolled ? 'View Materials' : 'Enroll Now'}
                        <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                      </button>
                      <span className="text-orange-400 font-bold">{program.price}</span>
                    </div>
                    {!isEnrolled && (
                      <button
                        onClick={() => handleTryFree(program.id)}
                        className="w-full py-2.5 bg-slate-800/50 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-800"
                      >
                        <Play className="w-3 h-3" /> Try Free Demo
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {filteredPrograms.length === 0 && (
          <div className="text-center py-20 space-y-4">
            <div className="bg-slate-900 w-20 h-20 rounded-full flex items-center justify-center mx-auto">
              <Filter className="w-10 h-10 text-slate-500" />
            </div>
            <h3 className="text-xl font-display font-bold text-white">No programs found</h3>
            <p className="text-slate-400">Try adjusting your filters or search query.</p>
          </div>
        )}
      </div>

      {/* Demo Modal */}
      {showDemoModal && selectedProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowDemoModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-2xl w-full relative z-10 shadow-2xl max-h-[80vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowDemoModal(false)}
              className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mb-8">
              <div className="inline-block py-1 px-3 rounded-full bg-orange-500/10 text-orange-400 text-[10px] font-bold uppercase tracking-widest mb-4 border border-orange-500/20">
                Free Preview
              </div>
              <h3 className="text-3xl font-display font-bold text-white mb-2">{selectedProgram.title} Demo</h3>
              <p className="text-slate-400">Get a taste of what you'll learn in this course. Enroll to get full access.</p>
            </div>

            <div className="space-y-8">
              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <PlayCircle className="w-5 h-5 text-sky-500" />
                  Demo Materials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {selectedProgram.demoMaterials?.map((material, idx) => (
                    <a 
                      key={idx}
                      href={material.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 bg-slate-950/50 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-sky-500 uppercase tracking-widest">{material.type}</span>
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-500 transition-colors" />
                      </div>
                      <h5 className="text-white font-bold text-sm mb-1">{material.title}</h5>
                      <p className="text-slate-500 text-xs">{material.description}</p>
                    </a>
                  ))}
                </div>
              </div>

              <div className="pt-8 border-t border-slate-800">
                <button
                  onClick={() => { setShowDemoModal(false); handleEnroll(selectedProgram.id); }}
                  className="w-full py-4 bg-sky-500 hover:bg-sky-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
                >
                  Enroll Now to Unlock Full Course <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Details Modal */}
      {showDetailsModal && selectedProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowDetailsModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-2xl w-full relative z-10 shadow-2xl max-h-[80vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowDetailsModal(false)}
              className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mb-8">
              <h3 className="text-3xl font-display font-bold text-white mb-2">{selectedProgram.title}</h3>
              <p className="text-sky-400 font-medium">{selectedProgram.category} • {selectedProgram.duration}</p>
            </div>

            <div className="space-y-8">
              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-sky-500" />
                  Reading Materials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {selectedProgram.readingMaterials?.map((material, idx) => (
                    <a 
                      key={idx}
                      href={material.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 bg-slate-950/50 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-sky-500 uppercase tracking-widest">{material.type}</span>
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-500 transition-colors" />
                      </div>
                      <h5 className="text-white font-bold text-sm mb-1">{material.title}</h5>
                      <p className="text-slate-500 text-xs">{material.description}</p>
                    </a>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-orange-500" />
                  Curriculum
                </h4>
                <div className="space-y-3">
                  {selectedProgram.curriculum.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-4 p-4 bg-slate-950/30 rounded-xl border border-slate-800/50">
                      <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400 shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <span className="text-slate-300 text-sm leading-relaxed">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => !isPaying && setShowPaymentModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-md w-full relative z-10 shadow-2xl"
          >
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-sky-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Lock className="w-10 h-10 text-sky-400" />
              </div>
              <h3 className="text-2xl font-bold mb-2 text-white">Unlock Your Potential</h3>
              <p className="text-slate-400">
                Complete your payment via M-Pesa to start your journey in {PROGRAMS.find(p => p.id === selectedProgramId)?.title}. Payments are sent to 0113271756.
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                <div className="text-sm text-slate-400 mb-1">Amount Due</div>
                <div className="text-2xl font-bold text-white">{PROGRAMS.find(p => p.id === selectedProgramId)?.price}</div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">M-Pesa Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g. 0712345678"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                />
              </div>

              <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                <div className="text-sm text-slate-400 mb-1">Payment Method</div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center font-bold text-white">M</div>
                  <span className="font-bold text-white">M-Pesa Express</span>
                </div>
              </div>
            </div>

            <button
              onClick={processPayment}
              disabled={isPaying || !phoneNumber}
              className="w-full py-4 bg-sky-500 hover:bg-sky-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
            >
              {isPaying ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </>
              ) : (
                'Pay with M-Pesa'
              )}
            </button>
            <button
              onClick={() => setShowPaymentModal(false)}
              disabled={isPaying}
              className="w-full py-4 text-slate-400 hover:text-white transition-colors mt-2 disabled:opacity-50"
            >
              Cancel
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
