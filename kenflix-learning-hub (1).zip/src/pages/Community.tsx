import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Calendar, MessageSquare, Heart, Share2, ArrowRight, Send, Image as ImageIcon, Trash2 } from 'lucide-react';
import { auth, db, signInWithGoogle } from '../firebase';
import { collection, query, orderBy, onSnapshot, addDoc, updateDoc, doc, deleteDoc, arrayUnion, arrayRemove, Timestamp } from 'firebase/firestore';
import { Post, Comment } from '../types';
import { cn } from '../lib/utils';

export function Community() {
  const [user, setUser] = useState(auth.currentUser);
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [commentInputs, setCommentInputs] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as Post[];
      setPosts(data);
    });
    return () => unsubscribe();
  }, []);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      await signInWithGoogle();
      return;
    }
    if (!newPostContent.trim()) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'posts'), {
        userId: user.uid,
        userName: user.displayName || 'Anonymous',
        userAvatar: user.photoURL || '',
        content: newPostContent,
        likes: [],
        comments: [],
        createdAt: new Date().toISOString()
      });
      setNewPostContent('');
    } catch (error) {
      console.error("Error creating post", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLike = async (postId: string, isLiked: boolean) => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    const postRef = doc(db, 'posts', postId);
    try {
      await updateDoc(postRef, {
        likes: isLiked ? arrayRemove(user.uid) : arrayUnion(user.uid)
      });
    } catch (error) {
      console.error("Error liking post", error);
    }
  };

  const handleAddComment = async (postId: string) => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    const content = commentInputs[postId];
    if (!content?.trim()) return;

    const postRef = doc(db, 'posts', postId);
    const newComment: Comment = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.uid,
      userName: user.displayName || 'Anonymous',
      content: content,
      createdAt: new Date().toISOString()
    };

    try {
      await updateDoc(postRef, {
        comments: arrayUnion(newComment)
      });
      setCommentInputs(prev => ({ ...prev, [postId]: '' }));
    } catch (error) {
      console.error("Error adding comment", error);
    }
  };

  const handleDeletePost = async (postId: string) => {
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch (error) {
      console.error("Error deleting post", error);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg pt-32 pb-20 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <motion.h1 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-display font-bold text-white"
          >
            Kenflix <span className="text-sky-500">Community</span>
          </motion.h1>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            Connect with thousands of learners across Africa. Share knowledge, find mentors, and grow your network.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Feed */}
          <div className="lg:col-span-2 space-y-8">
            {/* Create Post */}
            <div className="card-dark p-6">
              <form onSubmit={handleCreatePost} className="space-y-4">
                <div className="flex gap-4">
                  <img src={user?.photoURL || 'https://i.pravatar.cc/100?u=anon'} className="w-12 h-12 rounded-2xl" alt="" />
                  <textarea
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder="What's on your mind? Share your learning journey..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-white focus:ring-2 focus:ring-sky-500 outline-none transition-all resize-none h-32"
                  />
                </div>
                <div className="flex justify-between items-center pt-2">
                  <button type="button" className="flex items-center gap-2 text-slate-400 hover:text-sky-400 transition-colors font-bold text-sm">
                    <ImageIcon className="w-5 h-5" /> Add Image
                  </button>
                  <button 
                    disabled={isSubmitting || !newPostContent.trim()}
                    className="bg-sky-500 text-white px-8 py-2.5 rounded-xl font-bold hover:bg-sky-600 transition-all shadow-lg shadow-sky-500/20 disabled:opacity-50 flex items-center gap-2"
                  >
                    {isSubmitting ? 'Posting...' : 'Post Now'} <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            </div>

            {/* Posts List */}
            <div className="space-y-8">
              {posts.map((post) => {
                const isLiked = user ? post.likes.includes(user.uid) : false;
                return (
                  <motion.div 
                    key={post.id} 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="card-dark overflow-hidden"
                  >
                    <div className="p-6 space-y-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          <img src={post.userAvatar || `https://i.pravatar.cc/100?u=${post.userId}`} className="w-12 h-12 rounded-2xl" alt="" />
                          <div>
                            <h4 className="font-display font-bold text-white">{post.userName}</h4>
                            <p className="text-xs text-slate-500">
                              {new Date(post.createdAt).toLocaleDateString()} • {new Date(post.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          {user?.uid === post.userId && (
                            <button 
                              onClick={() => handleDeletePost(post.id)}
                              className="text-slate-500 hover:text-red-500 transition-colors p-2"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          )}
                          <button className="text-slate-500 hover:text-sky-400 transition-colors p-2">
                            <Share2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                      <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{post.content}</p>
                      {post.image && (
                        <div className="rounded-2xl overflow-hidden h-64">
                          <img src={post.image} className="w-full h-full object-cover" alt="" />
                        </div>
                      )}
                      
                      <div className="flex items-center gap-6 pt-4 border-t border-slate-800">
                        <button 
                          onClick={() => handleLike(post.id, isLiked)}
                          className={cn(
                            "flex items-center gap-2 text-sm font-bold transition-colors",
                            isLiked ? "text-red-500" : "text-slate-500 hover:text-red-500"
                          )}
                        >
                          <Heart className={cn("w-5 h-5", isLiked && "fill-current")} /> {post.likes.length}
                        </button>
                        <div className="flex items-center gap-2 text-sm font-bold text-slate-500">
                          <MessageSquare className="w-5 h-5" /> {post.comments.length}
                        </div>
                      </div>

                      {/* Comments Section */}
                      <div className="pt-4 space-y-4">
                        {post.comments.map((comment) => (
                          <div key={comment.id} className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800/50">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs font-bold text-sky-400">{comment.userName}</span>
                              <span className="text-[10px] text-slate-500">{new Date(comment.createdAt).toLocaleDateString()}</span>
                            </div>
                            <p className="text-sm text-slate-400">{comment.content}</p>
                          </div>
                        ))}
                        
                        <div className="flex gap-2 pt-2">
                          <input
                            type="text"
                            value={commentInputs[post.id] || ''}
                            onChange={(e) => setCommentInputs(prev => ({ ...prev, [post.id]: e.target.value }))}
                            placeholder="Add a comment..."
                            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                            onKeyPress={(e) => e.key === 'Enter' && handleAddComment(post.id)}
                          />
                          <button 
                            onClick={() => handleAddComment(post.id)}
                            className="bg-sky-500/10 text-sky-400 p-2 rounded-xl hover:bg-sky-500 hover:text-white transition-all"
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <div className="card-dark p-8 space-y-6">
              <h3 className="text-xl font-display font-bold text-white">Upcoming Events</h3>
              <div className="space-y-6">
                {[
                  { title: 'Web Design Workshop', date: 'Oct 20, 2023', time: '2:00 PM' },
                  { title: 'AI Tools Webinar', date: 'Oct 22, 2023', time: '4:00 PM' },
                  { title: 'Graduation Ceremony', date: 'Oct 25, 2023', time: '10:00 AM' }
                ].map((event, idx) => (
                  <div key={idx} className="flex gap-4 group cursor-pointer">
                    <div className="bg-sky-500/10 text-sky-400 p-3 rounded-2xl h-fit group-hover:bg-sky-500 group-hover:text-white transition-all">
                      <Calendar className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-white group-hover:text-sky-400 transition-colors">{event.title}</h4>
                      <p className="text-xs text-slate-500">{event.date} • {event.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full py-3 text-sm font-bold text-sky-400 hover:bg-sky-500/5 rounded-xl transition-colors flex items-center justify-center gap-2">
                View All Events <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-orange-500 p-8 rounded-[2rem] text-white space-y-6 shadow-xl shadow-orange-500/20">
              <h3 className="text-xl font-display font-bold">Women & Tech</h3>
              <p className="text-sm text-white/80 leading-relaxed">Join our exclusive community for women in technology across Africa. Mentorship, networking, and growth.</p>
              <button className="w-full bg-white text-orange-500 py-3 rounded-xl font-bold text-sm hover:bg-slate-100 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
