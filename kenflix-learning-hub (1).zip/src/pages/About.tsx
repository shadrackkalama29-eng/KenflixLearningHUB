import { motion } from 'motion/react';
import { GraduationCap, Users, Globe, Award, Heart, Shield } from 'lucide-react';

export function About() {
  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <div className="text-center mb-20 space-y-6">
          <h1 className="text-4xl md:text-6xl font-display font-bold text-secondary">Empowering Africa's <br /><span className="text-primary">Digital Future</span></h1>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto leading-relaxed">
            Kenflix Learning Hub is a leading EdTech platform dedicated to providing practical, industry-focused digital skills to learners across the continent.
          </p>
        </div>

        {/* Vision/Mission */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-24">
          <div className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm space-y-6">
            <div className="bg-primary/10 w-16 h-16 rounded-2xl flex items-center justify-center text-primary">
              <Heart className="w-8 h-8" />
            </div>
            <h2 className="text-3xl font-display font-bold text-secondary">Our Mission</h2>
            <p className="text-slate-600 leading-relaxed">
              To democratize access to high-quality digital education and empower individuals with the skills needed to thrive in the global digital economy. We believe that talent is universal, but opportunity is not.
            </p>
          </div>
          <div className="bg-secondary p-10 rounded-[40px] text-white space-y-6">
            <div className="bg-white/10 w-16 h-16 rounded-2xl flex items-center justify-center text-white">
              <Globe className="w-8 h-8" />
            </div>
            <h2 className="text-3xl font-display font-bold">Our Vision</h2>
            <p className="text-slate-300 leading-relaxed">
              To be the premier destination for digital skill acquisition in Africa, fostering a community of innovators, creators, and leaders who drive positive change in their communities and beyond.
            </p>
          </div>
        </div>

        {/* Values */}
        <div className="space-y-12 mb-24">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-display font-bold text-secondary">Our Core Values</h2>
            <p className="text-slate-500">The principles that guide everything we do.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Shield, title: 'Integrity', desc: 'We maintain the highest standards of honesty and transparency in our education.' },
              { icon: Award, title: 'Excellence', desc: 'We strive for excellence in our curriculum, teaching, and student support.' },
              { icon: Users, title: 'Community', desc: 'We believe in the power of collaboration and mutual growth.' }
            ].map((value, idx) => (
              <div key={idx} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center space-y-4">
                <div className="bg-slate-50 w-16 h-16 rounded-2xl flex items-center justify-center text-primary mx-auto">
                  <value.icon className="w-8 h-8" />
                </div>
                <h4 className="font-display font-bold text-secondary text-xl">{value.title}</h4>
                <p className="text-sm text-slate-600 leading-relaxed">{value.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Team Section */}
        <div className="space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-display font-bold text-secondary">Meet Our Leadership</h2>
            <p className="text-slate-500">The visionaries behind Kenflix Learning Hub.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { name: 'Dr. Ken Okoro', role: 'Founder & CEO', img: 'https://i.pravatar.cc/150?u=ken' },
              { name: 'Sarah Mensah', role: 'Head of Education', img: 'https://i.pravatar.cc/150?u=sarah2' },
              { name: 'David Okafor', role: 'CTO', img: 'https://i.pravatar.cc/150?u=david2' },
              { name: 'Amara Eze', role: 'Head of Community', img: 'https://i.pravatar.cc/150?u=amara' }
            ].map((member, idx) => (
              <div key={idx} className="text-center space-y-4">
                <div className="relative group">
                  <img src={member.img} alt={member.name} className="w-full aspect-square rounded-[40px] object-cover shadow-lg group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-primary/20 rounded-[40px] opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <div>
                  <h4 className="font-display font-bold text-secondary text-lg">{member.name}</h4>
                  <p className="text-sm text-primary font-medium">{member.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
