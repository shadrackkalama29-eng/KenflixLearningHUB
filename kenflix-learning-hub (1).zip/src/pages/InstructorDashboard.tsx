import { motion } from 'motion/react';
import { Plus, Users, BookOpen, MessageSquare, BarChart3, Upload, FileText, CheckCircle } from 'lucide-react';

export function InstructorDashboard() {
  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-3xl font-display font-bold text-secondary">Instructor Dashboard</h1>
            <p className="text-slate-500">Manage your courses, students, and content.</p>
          </div>
          <button className="bg-primary text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
            <Plus className="w-5 h-5" /> Create New Course
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {[
            { label: 'Total Students', value: '1,248', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'Active Courses', value: '4', icon: BookOpen, color: 'text-purple-600', bg: 'bg-purple-50' },
            { label: 'Pending Reviews', value: '12', icon: MessageSquare, color: 'text-orange-600', bg: 'bg-orange-50' },
            { label: 'Course Rating', value: '4.9', icon: BarChart3, color: 'text-green-600', bg: 'bg-green-50' }
          ].map((stat, idx) => (
            <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
              <div className={`${stat.bg} p-4 rounded-2xl`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">{stat.label}</p>
                <p className="text-2xl font-display font-bold text-secondary">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              <h3 className="text-xl font-display font-bold text-secondary">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { label: 'Upload Lesson', icon: Upload, color: 'bg-primary' },
                  { label: 'Create Quiz', icon: FileText, color: 'bg-accent' },
                  { label: 'Grade Students', icon: CheckCircle, color: 'bg-secondary' }
                ].map((action, idx) => (
                  <button key={idx} className="flex flex-col items-center gap-4 p-6 rounded-2xl border border-slate-100 hover:border-primary hover:bg-slate-50 transition-all group">
                    <div className={`${action.color} p-4 rounded-2xl text-white group-hover:scale-110 transition-transform`}>
                      <action.icon className="w-6 h-6" />
                    </div>
                    <span className="text-sm font-bold text-secondary">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              <h3 className="text-xl font-display font-bold text-secondary">Active Students</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-100">
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Student</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Course</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Progress</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {[
                      { name: 'Alice Smith', course: 'Graphic Design', progress: '85%', status: 'Active' },
                      { name: 'Bob Johnson', course: 'Web Design', progress: '45%', status: 'Active' },
                      { name: 'Charlie Brown', course: 'AI Tools', progress: '100%', status: 'Completed' }
                    ].map((student, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 transition-colors">
                        <td className="py-4 flex items-center gap-3">
                          <img src={`https://i.pravatar.cc/100?u=${student.name}`} className="w-8 h-8 rounded-full" alt="" />
                          <span className="text-sm font-bold text-secondary">{student.name}</span>
                        </td>
                        <td className="py-4 text-sm text-slate-600">{student.course}</td>
                        <td className="py-4">
                          <div className="w-24 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <div className="bg-primary h-full" style={{ width: student.progress }}></div>
                          </div>
                        </td>
                        <td className="py-4">
                          <span className={`text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider ${
                            student.status === 'Completed' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'
                          }`}>
                            {student.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              <h3 className="text-xl font-display font-bold text-secondary">Course Performance</h3>
              <div className="space-y-6">
                {[
                  { name: 'Graphic Design', value: 85 },
                  { name: 'Web Design', value: 62 },
                  { name: 'AI Tools', value: 45 }
                ].map((course, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between text-sm font-bold">
                      <span className="text-secondary">{course.name}</span>
                      <span className="text-primary">{course.value}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-primary h-full" style={{ width: `${course.value}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-secondary p-8 rounded-3xl text-white space-y-6">
              <h3 className="text-xl font-display font-bold">Need Help?</h3>
              <p className="text-sm text-slate-300">Check our instructor guide or contact support for assistance with course creation.</p>
              <button className="w-full bg-white text-secondary py-3 rounded-xl font-bold text-sm hover:bg-slate-100 transition-colors">
                View Instructor Guide
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
