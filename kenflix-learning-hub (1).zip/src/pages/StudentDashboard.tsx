import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, CheckCircle, Clock, Award, Users, ChevronRight, PlayCircle, Lock, LogOut, Settings, Bell, X, FileText, ArrowRight } from 'lucide-react';
import { PROGRAMS } from '../constants';
import { auth, db } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { Enrollment, Program } from '../types';
import { useNavigate } from 'react-router-dom';

export function StudentDashboard() {
  const [user, setUser] = useState(auth.currentUser);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [showMaterialsModal, setShowMaterialsModal] = useState(false);
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      if (!u) {
        navigate('/login');
      } else {
        setUser(u);
      }
    });
    return () => unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (user) {
      const q = query(collection(db, 'enrollments'), where('userId', '==', user.uid));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setEnrollments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Enrollment)));
      });
      return () => unsubscribe();
    }
  }, [user]);

  const activeEnrollment = enrollments.find(e => e.status === 'active');
  const program = activeEnrollment ? PROGRAMS.find(p => p.id === activeEnrollment.programId) : PROGRAMS[0];

  if (!user) return null;

  return (
    <div className="min-h-screen bg-dark-bg pt-24 pb-20 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="card-dark p-6 space-y-6">
              <div className="text-center space-y-3">
                <div className="relative inline-block">
                  <img src={user.photoURL || "https://i.pravatar.cc/150?u=student"} className="w-24 h-24 rounded-2xl mx-auto shadow-xl border-2 border-sky-500/20" alt="Student" />
                  <div className="absolute -bottom-2 -right-2 bg-emerald-500 w-5 h-5 rounded-full border-4 border-dark-card" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-white text-lg">{user.displayName || 'Student'}</h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">ID: #KH-{user.uid.slice(0, 6).toUpperCase()}</p>
                </div>
              </div>
              <nav className="space-y-1">
                {[
                  { icon: BookOpen, name: 'My Learning', active: true },
                  { icon: Users, name: 'Community', active: false, path: '/community' },
                  { icon: Award, name: 'Certificates', active: false },
                  { icon: Bell, name: 'Notifications', active: false },
                  { icon: Settings, name: 'Settings', active: false }
                ].map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => item.path && navigate(item.path)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                      item.active ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <item.icon className="w-4 h-4" />
                    {item.name}
                  </button>
                ))}
              </nav>
              <button 
                onClick={() => auth.signOut()}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-all border border-transparent hover:border-rose-500/20"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>

            <div className="bg-gradient-to-br from-sky-500 to-sky-600 p-6 rounded-3xl text-white space-y-4 shadow-xl shadow-sky-500/20">
              <div className="bg-white/20 w-10 h-10 rounded-xl flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold">Next Live Session</h4>
                <p className="text-xs text-white/80 mt-1">Design Review with Sarah Johnson</p>
              </div>
              <div className="flex items-center gap-2 text-sm font-bold bg-black/10 p-2 rounded-lg">
                <Clock className="w-4 h-4" /> Today, 4:00 PM
              </div>
              <button className="w-full bg-white text-sky-600 py-3 rounded-xl text-xs font-bold hover:bg-slate-100 transition-colors shadow-lg">
                Join Meeting
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            <div className="card-dark p-8 space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-sky-500/5 rounded-full blur-3xl -mr-32 -mt-32" />
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
                <div>
                  <h2 className="text-3xl font-display font-bold text-white">Welcome back, {user.displayName?.split(' ')[0]}!</h2>
                  <p className="text-slate-400 text-sm mt-1">You're doing great! You've completed {activeEnrollment?.progress || 0}% of your current course.</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 px-6 py-3 rounded-2xl flex items-center gap-4">
                  <div className="text-right">
                    <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest">Progress</span>
                    <span className="text-sky-400 font-bold text-xl">{activeEnrollment?.progress || 0}%</span>
                  </div>
                  <div className="w-12 h-12 rounded-full border-4 border-slate-700 border-t-sky-500 flex items-center justify-center">
                    <span className="text-[10px] font-bold text-white">{activeEnrollment?.progress || 0}%</span>
                  </div>
                </div>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${activeEnrollment?.progress || 0}%` }}
                  className="bg-sky-500 h-full shadow-[0_0_15px_rgba(14,165,233,0.5)]"
                ></motion.div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-display font-bold text-white">Course Modules</h3>
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => {
                      if (program) {
                        setSelectedProgram(program);
                        setShowMaterialsModal(true);
                      }
                    }}
                    className="text-xs font-bold text-sky-400 uppercase tracking-widest hover:text-sky-300 flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" /> View All Materials
                  </button>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">{program?.title}</span>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {program?.curriculum.map((module, idx) => {
                  const isCompleted = activeEnrollment?.completedModules?.includes(module.week.toString());
                  const isLocked = !isCompleted && idx > (activeEnrollment?.completedModules?.length || 0);
                  
                  return (
                    <div 
                      key={idx}
                      className={`card-dark p-6 flex items-center justify-between transition-all ${
                        isLocked ? 'opacity-50 grayscale' : 'hover:border-sky-500/50 cursor-pointer group'
                      }`}
                    >
                      <div className="flex items-center gap-6">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-display font-bold transition-all ${
                          isCompleted 
                            ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' 
                            : !isLocked 
                              ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20' 
                              : 'bg-slate-800 text-slate-500'
                        }`}>
                          {isCompleted ? <CheckCircle className="w-7 h-7" /> : module.week}
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Week {module.week}</p>
                          <h4 className="font-display font-bold text-white group-hover:text-sky-400 transition-colors">{module.title}</h4>
                          <p className="text-xs text-slate-500 mt-1">{module.content}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        {isLocked ? (
                          <div className="flex items-center gap-2 text-slate-500 text-xs font-bold uppercase tracking-widest bg-slate-800/50 px-3 py-1.5 rounded-lg">
                            <Lock className="w-3 h-3" /> Locked
                          </div>
                        ) : (
                          <button className="flex items-center gap-2 bg-sky-500 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-sky-600 transition-all shadow-lg shadow-sky-500/20">
                            <PlayCircle className="w-4 h-4" /> {isCompleted ? 'Review' : 'Resume'}
                          </button>
                        )}
                        <ChevronRight className="w-5 h-5 text-slate-700 group-hover:text-sky-500 transition-colors" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Materials Modal */}
      {showMaterialsModal && selectedProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowMaterialsModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-2xl w-full relative z-10 shadow-2xl max-h-[80vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowMaterialsModal(false)}
              className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mb-8">
              <div className="inline-block py-1 px-3 rounded-full bg-sky-500/10 text-sky-400 text-[10px] font-bold uppercase tracking-widest mb-4 border border-sky-500/20">
                Course Materials
              </div>
              <h3 className="text-3xl font-display font-bold text-white mb-2">{selectedProgram.title}</h3>
              <p className="text-slate-400">Access all reading materials and resources for this course.</p>
            </div>

            <div className="space-y-6">
              {selectedProgram.readingMaterials.map((material, idx) => (
                <a 
                  key={idx}
                  href={material.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 bg-slate-950/50 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-sky-500/10 rounded-xl flex items-center justify-center">
                      <FileText className="w-6 h-6 text-sky-400" />
                    </div>
                    <div>
                      <h4 className="text-white font-bold">{material.title}</h4>
                      <p className="text-slate-500 text-xs mt-1">{material.description || 'Course reading material'}</p>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-slate-700 group-hover:text-sky-500 transition-transform group-hover:translate-x-1" />
                </a>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
