import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle, Users, Trophy, Star, Lock, Bell, Play, Clock, X, BookOpen, GraduationCap, PlayCircle, FileText, ArrowRight as ArrowRightIcon, ChevronRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { PROGRAMS } from '../constants';
import { auth, db, signInWithGoogle } from '../firebase';
import { collection, query, where, onSnapshot, doc, setDoc, Timestamp } from 'firebase/firestore';
import { Enrollment } from '../types';
import { cn } from '../lib/utils';

export function Home() {
  const navigate = useNavigate();
  const [user, setUser] = useState(auth.currentUser);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [selectedProgramId, setSelectedProgramId] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Tech', 'Data', 'Marketing', 'Design', 'Business'];

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(collection(db, 'enrollments'), where('userId', '==', user.uid));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const data = snapshot.docs.map(docSnap => {
          const d = { id: docSnap.id, ...docSnap.data() } as Enrollment;
          // Check if due date has passed and lock if necessary
          const now = new Date();
          const due = new Date(d.dueDate);
          if (now > due && d.status === 'active') {
            setDoc(doc(db, 'enrollments', d.id), { ...d, status: 'locked' }, { merge: true });
            return { ...d, status: 'locked' };
          }
          return d;
        });
        setEnrollments(data);
      });
      return () => unsubscribe();
    }
  }, [user]);

  const handleEnroll = async (programId: string) => {
    if (!user) {
      try {
        await signInWithGoogle();
      } catch (error) {
        console.error("Login failed", error);
        return;
      }
    }

    const existingEnrollment = enrollments.find(e => e.programId === programId);
    
    if (existingEnrollment) {
      if (existingEnrollment.status === 'locked') {
        setSelectedProgramId(programId);
        setShowPaymentModal(true);
      } else {
        setSelectedProgramId(programId);
        setShowDetailsModal(true);
      }
    } else {
      setSelectedProgramId(programId);
      setShowPaymentModal(true);
    }
  };

  const handleTryFree = (programId: string) => {
    setSelectedProgramId(programId);
    setShowDemoModal(true);
  };

  const selectedProgram = PROGRAMS.find(p => p.id === selectedProgramId);

  const [phoneNumber, setPhoneNumber] = useState('');
  const [isPaying, setIsPaying] = useState(false);

  const processPayment = async () => {
    if (!user || !selectedProgramId || !phoneNumber) return;

    setIsPaying(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const enrollmentId = `${user.uid}_${selectedProgramId}`;
    const dueDate = new Timestamp(Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60, 0); // 30 days from now

    await setDoc(doc(db, 'enrollments', enrollmentId), {
      id: enrollmentId,
      userId: user.uid,
      programId: selectedProgramId,
      status: 'active',
      progress: 0,
      completedModules: [],
      dueDate: dueDate.toDate().toISOString(),
      lastPaymentDate: new Date().toISOString()
    });

    setIsPaying(false);
    setShowPaymentModal(false);
    navigate(`/programs/${selectedProgramId}`);
  };

  return (
    <div className="min-h-screen bg-dark-bg text-slate-200">
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden hero-gradient">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-20 right-20 w-96 h-96 bg-sky-500/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 left-20 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse delay-700" />
        </div>

        <div className="container mx-auto px-6 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <span className="inline-block py-1 px-4 rounded-full bg-sky-500/10 text-sky-400 text-sm font-semibold mb-6 border border-sky-500/20">
              Empowering Africa's Next Tech Leaders
            </span>
            <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight text-white">
              Master the Skills of the <span className="text-sky-400">Future</span>
            </h1>
            <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto">
              Join Kenflix Hub and gain access to world-class training in Software Engineering, Data Science, and more. Real content, real projects, real results.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/programs"
                className="w-full sm:w-auto px-8 py-4 bg-sky-500 hover:bg-sky-600 text-white rounded-xl font-bold transition-all flex items-center justify-center gap-2 group shadow-lg shadow-sky-500/25"
              >
                Explore Programs
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <button 
                onClick={() => !user && signInWithGoogle()}
                className="w-full sm:w-auto px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold border border-slate-700 transition-all flex items-center justify-center gap-2"
              >
                {user ? 'Welcome Back' : (
                  <>
                    <Play className="w-5 h-5 fill-current" />
                    Get Started Free
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-slate-900/50 border-y border-slate-800">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { icon: Users, label: 'Active Students', value: '10K+' },
              { icon: Trophy, label: 'Success Rate', value: '94%' },
              { icon: Star, label: 'Expert Mentors', value: '50+' },
              { icon: CheckCircle, label: 'Courses', value: '25+' },
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <stat.icon className="w-8 h-8 text-orange-500 mx-auto mb-4" />
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-slate-400 uppercase tracking-wider">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Programs */}
      <section className="py-24 container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-4xl font-bold mb-4 text-white">Popular Programs</h2>
            <p className="text-slate-400 text-lg">
              Start your journey today with our most sought-after courses. Real-world skills for the modern economy.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={cn(
                  "px-6 py-2 rounded-full text-sm font-bold transition-all border-2",
                  activeFilter === filter 
                    ? "bg-sky-500 text-white border-sky-500 shadow-lg shadow-sky-500/20" 
                    : "bg-slate-800 text-slate-400 border-slate-700 hover:border-sky-500/30 hover:text-sky-400"
                )}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROGRAMS.filter(p => activeFilter === 'All' || p.category === activeFilter).slice(0, 3).map((program) => {
            const enrollment = enrollments.find(e => e.programId === program.id);
            const isLocked = enrollment?.status === 'locked';
            const isEnrolled = !!enrollment;

            return (
              <motion.div
                key={program.id}
                whileHover={{ y: -10 }}
                className="card-dark group"
              >
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 right-4 bg-slate-900/80 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-bold border border-white/10 uppercase tracking-wider">
                    {program.category}
                  </div>
                  {isLocked && (
                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center">
                      <div className="text-center">
                        <Lock className="w-10 h-10 text-orange-500 mx-auto mb-2" />
                        <span className="text-white font-bold">Payment Due</span>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-1.5 text-sky-400 text-sm font-semibold">
                      <Clock className="w-4 h-4" />
                      {program.duration}
                    </div>
                    <span className="w-1 h-1 bg-slate-700 rounded-full" />
                    <span className="text-orange-400 text-sm font-bold">{program.price}</span>
                  </div>
                  <h3 className="text-2xl font-bold mb-3 group-hover:text-sky-400 transition-colors text-white">{program.title}</h3>
                  <p className="text-slate-400 mb-8 line-clamp-2 text-sm leading-relaxed">
                    {program.description}
                  </p>
                  <div className="flex flex-col gap-3">
                    <button
                      onClick={() => handleEnroll(program.id)}
                      className={`w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
                        isLocked 
                          ? 'bg-orange-500 hover:bg-orange-600 text-white' 
                          : isEnrolled 
                            ? 'bg-slate-800 text-sky-400 border border-sky-500/30' 
                            : 'bg-sky-500 hover:bg-sky-600 text-white shadow-lg shadow-sky-500/20'
                      }`}
                    >
                      {isLocked ? 'Pay to Unlock' : isEnrolled ? 'View Materials' : 'Enroll Now'}
                      {!isEnrolled && <ArrowRight className="w-5 h-5" />}
                    </button>
                    {!isEnrolled && (
                      <button
                        onClick={() => handleTryFree(program.id)}
                        className="w-full py-3 text-slate-400 hover:text-white transition-colors text-sm font-bold flex items-center justify-center gap-2"
                      >
                        <Play className="w-4 h-4" /> Try Free Demo
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Demo Modal */}
      {showDemoModal && selectedProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowDemoModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-2xl w-full relative z-10 shadow-2xl max-h-[80vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowDemoModal(false)}
              className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mb-8">
              <div className="inline-block py-1 px-3 rounded-full bg-orange-500/10 text-orange-400 text-[10px] font-bold uppercase tracking-widest mb-4 border border-orange-500/20">
                Free Preview
              </div>
              <h3 className="text-3xl font-display font-bold text-white mb-2">{selectedProgram.title} Demo</h3>
              <p className="text-slate-400">Get a taste of what you'll learn in this course. Enroll to get full access.</p>
            </div>

            <div className="space-y-8">
              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <PlayCircle className="w-5 h-5 text-sky-500" />
                  Demo Materials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {selectedProgram.demoMaterials?.map((material, idx) => (
                    <a 
                      key={idx}
                      href={material.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 bg-slate-950/50 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-sky-500 uppercase tracking-widest">{material.type}</span>
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-500 transition-colors" />
                      </div>
                      <h5 className="text-white font-bold text-sm mb-1">{material.title}</h5>
                      <p className="text-slate-500 text-xs">{material.description}</p>
                    </a>
                  ))}
                </div>
              </div>

              <div className="pt-8 border-t border-slate-800">
                <button
                  onClick={() => { setShowDemoModal(false); handleEnroll(selectedProgram.id); }}
                  className="w-full py-4 bg-sky-500 hover:bg-sky-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
                >
                  Enroll Now to Unlock Full Course <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Details Modal */}
      {showDetailsModal && selectedProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowDetailsModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-2xl w-full relative z-10 shadow-2xl max-h-[80vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowDetailsModal(false)}
              className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mb-8">
              <h3 className="text-3xl font-display font-bold text-white mb-2">{selectedProgram.title}</h3>
              <p className="text-sky-400 font-medium">{selectedProgram.category} • {selectedProgram.duration}</p>
            </div>

            <div className="space-y-8">
              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-sky-500" />
                  Reading Materials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {selectedProgram.readingMaterials?.map((material, idx) => (
                    <a 
                      key={idx}
                      href={material.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 bg-slate-950/50 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-sky-500 uppercase tracking-widest">{material.type}</span>
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-500 transition-colors" />
                      </div>
                      <h5 className="text-white font-bold text-sm mb-1">{material.title}</h5>
                      <p className="text-slate-500 text-xs">{material.description}</p>
                    </a>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-orange-500" />
                  Curriculum
                </h4>
                <div className="space-y-3">
                  {selectedProgram.curriculum.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-4 p-4 bg-slate-950/30 rounded-xl border border-slate-800/50">
                      <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400 shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <span className="text-slate-300 text-sm leading-relaxed">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => !isPaying && setShowPaymentModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-md w-full relative z-10 shadow-2xl"
          >
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-sky-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Lock className="w-10 h-10 text-sky-400" />
              </div>
              <h3 className="text-2xl font-bold mb-2 text-white">Unlock Your Potential</h3>
              <p className="text-slate-400">
                Complete your payment via M-Pesa to start your journey in {PROGRAMS.find(p => p.id === selectedProgramId)?.title}. Payments are sent to 0113271756.
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                <div className="text-sm text-slate-400 mb-1">Amount Due</div>
                <div className="text-2xl font-bold text-white">{PROGRAMS.find(p => p.id === selectedProgramId)?.price}</div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">M-Pesa Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g. 0712345678"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                />
              </div>

              <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                <div className="text-sm text-slate-400 mb-1">Payment Method</div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center font-bold text-white">M</div>
                  <span className="font-bold text-white">M-Pesa Express</span>
                </div>
              </div>
            </div>

            <button
              onClick={processPayment}
              disabled={isPaying || !phoneNumber}
              className="w-full py-4 bg-sky-500 hover:bg-sky-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
            >
              {isPaying ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </>
              ) : (
                'Pay with M-Pesa'
              )}
            </button>
            <button
              onClick={() => setShowPaymentModal(false)}
              disabled={isPaying}
              className="w-full py-4 text-slate-400 hover:text-white transition-colors mt-2 disabled:opacity-50"
            >
              Cancel
            </button>
          </motion.div>
        </div>
      )}

      {/* Notifications for Due Dates */}
      {enrollments.some(e => {
        const due = new Date(e.dueDate);
        const now = new Date();
        const diff = due.getTime() - now.getTime();
        return diff > 0 && diff < 3 * 24 * 60 * 60 * 1000; // Less than 3 days
      }) && (
        <div className="fixed bottom-6 right-6 z-40">
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            className="bg-orange-500 text-white p-4 rounded-2xl shadow-2xl flex items-center gap-4 max-w-sm"
          >
            <div className="bg-white/20 p-2 rounded-xl">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold">Payment Reminder</div>
              <div className="text-sm opacity-90">Your subscription for one of your courses is expiring soon.</div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

