import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, BarChart, Calendar, CheckCircle2, PlayCircle, Lock, ChevronDown, User, Star, Award, Globe, Users, X, ArrowRight, BookOpen, GraduationCap } from 'lucide-react';
import { PROGRAMS } from '../constants';
import { auth, db, signInWithGoogle } from '../firebase';
import { collection, query, where, onSnapshot, doc, setDoc, Timestamp } from 'firebase/firestore';
import { Enrollment } from '../types';

export function ProgramDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const program = PROGRAMS.find(p => p.id === id);
  const [user, setUser] = useState(auth.currentUser);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isPaying, setIsPaying] = useState(false);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(collection(db, 'enrollments'), where('userId', '==', user.uid));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setEnrollments(snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() } as Enrollment)));
      });
      return () => unsubscribe();
    }
  }, [user]);

  const enrollment = enrollments.find(e => e.programId === id);
  const isEnrolled = !!enrollment;
  const isLocked = enrollment?.status === 'locked';

  const handleEnroll = async () => {
    if (!user) {
      try {
        await signInWithGoogle();
      } catch (error) {
        console.error("Login failed", error);
        return;
      }
    }

    if (isEnrolled && !isLocked) {
      navigate('/dashboard');
    } else {
      setShowPaymentModal(true);
    }
  };

  const processPayment = async () => {
    if (!user || !id || !phoneNumber) return;

    setIsPaying(true);
    await new Promise(resolve => setTimeout(resolve, 2000));

    const enrollmentId = `${user.uid}_${id}`;
    const dueDate = new Timestamp(Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60, 0);

    await setDoc(doc(db, 'enrollments', enrollmentId), {
      id: enrollmentId,
      userId: user.uid,
      programId: id,
      status: 'active',
      progress: 0,
      completedModules: [],
      dueDate: dueDate.toDate().toISOString(),
      lastPaymentDate: new Date().toISOString()
    });

    setIsPaying(false);
    setShowPaymentModal(false);
    navigate('/dashboard');
  };

  if (!program) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-display font-bold">Program not found</h2>
          <Link to="/programs" className="text-primary font-bold">Back to Programs</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-bg pt-24 pb-20 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Left Content */}
          <div className="lg:col-span-2 space-y-12">
            <div className="space-y-6">
              <nav className="flex text-sm text-slate-500 gap-2">
                <Link to="/programs" className="hover:text-sky-400">Programs</Link>
                <span>/</span>
                <span className="text-sky-400 font-medium">{program.title}</span>
              </nav>
              <h1 className="text-4xl md:text-5xl font-display font-bold text-white leading-tight">
                {program.title}
              </h1>
              <p className="text-lg text-slate-400 leading-relaxed">
                {program.description}
              </p>
              
              <div className="flex flex-wrap gap-6 pt-4">
                <div className="flex items-center gap-2">
                  <div className="bg-sky-500/10 p-2 rounded-lg">
                    <Clock className="w-5 h-5 text-sky-400" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium">Duration</p>
                    <p className="text-sm font-bold text-white">{program.duration}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="bg-orange-500/10 p-2 rounded-lg">
                    <BarChart className="w-5 h-5 text-orange-400" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium">Level</p>
                    <p className="text-sm font-bold text-white">{program.level}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="bg-yellow-500/10 p-2 rounded-lg">
                    <Calendar className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-medium">Start Date</p>
                    <p className="text-sm font-bold text-white">{program.startDate}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Overview */}
            <section className="card-dark p-8 space-y-6">
              <h2 className="text-2xl font-display font-bold text-white">Course Overview</h2>
              <p className="text-slate-400 leading-relaxed">
                This program is designed to take you from the basics to advanced concepts through a series of practical exercises and real-world projects. By the end of this course, you will have a professional portfolio that demonstrates your expertise to potential employers or clients.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  'Hands-on practical exercises',
                  'Industry-recognized certification',
                  'Direct mentorship from experts',
                  'Lifetime access to materials',
                  'Career placement support',
                  'Community networking events'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-orange-400" />
                    <span className="text-sm text-slate-400">{item}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* Curriculum */}
            <section className="space-y-6">
              <h2 className="text-2xl font-display font-bold text-white">Curriculum</h2>
              <div className="space-y-4">
                {program.curriculum.map((item, idx) => (
                  <div key={idx} className="card-dark overflow-hidden">
                    <div className="p-5 flex items-center justify-between cursor-pointer hover:bg-slate-800/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center font-bold text-sky-400">
                          {item.week}
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">Week {item.week}</p>
                          <h4 className="font-display font-bold text-white">{item.title}</h4>
                        </div>
                      </div>
                      <ChevronDown className="w-5 h-5 text-slate-600" />
                    </div>
                    <div className="px-5 pb-5 pt-0 border-t border-slate-800/50">
                      <div className="mt-4 space-y-3">
                        <div className="flex items-center justify-between text-sm p-3 bg-slate-950/50 rounded-xl">
                          <div className="flex items-center gap-3">
                            <PlayCircle className="w-4 h-4 text-sky-400" />
                            <span className="text-slate-300">{item.content}</span>
                          </div>
                          <span className="text-slate-500">15:00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Instructor */}
            <section className="card-dark p-8 flex flex-col md:flex-row gap-8 items-center md:items-start">
              <img src={program.instructor.avatar} alt={program.instructor.name} className="w-24 h-24 rounded-2xl object-cover shadow-lg border border-slate-700" />
              <div className="space-y-4 text-center md:text-left">
                <div>
                  <h3 className="text-xl font-display font-bold text-white">{program.instructor.name}</h3>
                  <p className="text-sky-400 font-medium">{program.instructor.role}</p>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  With over 10 years of experience in the industry, {program.instructor.name.split(' ')[0]} has helped hundreds of students transition into digital careers. Expert in {program.category.toLowerCase()} and passionate about teaching.
                </p>
                <div className="flex justify-center md:justify-start gap-4">
                  <div className="flex items-center gap-1 text-xs text-slate-500">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" /> 4.9 Instructor Rating
                  </div>
                  <div className="flex items-center gap-1 text-xs text-slate-500">
                    <User className="w-4 h-4 text-sky-400" /> 1,200+ Students
                  </div>
                </div>
              </div>
            </section>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-8">
            <div className="sticky top-24 card-dark p-8 space-y-8 shadow-2xl shadow-sky-500/5">
              <div className="space-y-2">
                <p className="text-slate-400 font-medium">Course Price</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-display font-bold text-white">{program.price}</span>
                  <span className="text-slate-600 line-through">$399</span>
                </div>
                <p className="text-orange-400 text-sm font-bold">Limited time offer - 50% OFF</p>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={handleEnroll}
                  className="w-full bg-sky-500 text-white py-4 rounded-2xl font-bold text-lg hover:bg-sky-600 transition-all shadow-lg shadow-sky-500/20"
                >
                  {isLocked ? 'Unlock Course' : isEnrolled ? 'Go to Dashboard' : 'Enroll Now'}
                </button>
                {!isEnrolled && (
                  <button 
                    onClick={() => setShowDemoModal(true)}
                    className="w-full border-2 border-slate-800 text-white py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all"
                  >
                    Try Free Preview
                  </button>
                )}
              </div>

              <div className="space-y-4 pt-4 border-t border-slate-800">
                <p className="text-sm font-bold text-white">This course includes:</p>
                <ul className="space-y-3">
                  {[
                    { icon: Clock, text: 'Full lifetime access' },
                    { icon: Award, text: 'Certificate of completion' },
                    { icon: Globe, text: 'Access on mobile and TV' },
                    { icon: Users, text: 'Community access' }
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-sm text-slate-400">
                      <item.icon className="w-4 h-4 text-sky-400" />
                      {item.text}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-950/50 p-4 rounded-2xl text-center border border-slate-800">
                <p className="text-xs text-slate-500">30-Day Money-Back Guarantee</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Demo Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => setShowDemoModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-2xl w-full relative z-10 shadow-2xl max-h-[80vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowDemoModal(false)}
              className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="mb-8">
              <div className="inline-block py-1 px-3 rounded-full bg-orange-500/10 text-orange-400 text-[10px] font-bold uppercase tracking-widest mb-4 border border-orange-500/20">
                Free Preview
              </div>
              <h3 className="text-3xl font-display font-bold text-white mb-2">{program.title} Demo</h3>
              <p className="text-slate-400">Get a taste of what you'll learn in this course. Enroll to get full access.</p>
            </div>

            <div className="space-y-8">
              <div>
                <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <PlayCircle className="w-5 h-5 text-sky-500" />
                  Demo Materials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {program.demoMaterials?.map((material, idx) => (
                    <a 
                      key={idx}
                      href={material.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-4 bg-slate-950/50 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-sky-500 uppercase tracking-widest">{material.type}</span>
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-500 transition-colors" />
                      </div>
                      <h5 className="text-white font-bold text-sm mb-1">{material.title}</h5>
                      <p className="text-slate-500 text-xs">{material.description}</p>
                    </a>
                  ))}
                </div>
              </div>

              <div className="pt-8 border-t border-slate-800">
                <button
                  onClick={() => { setShowDemoModal(false); handleEnroll(); }}
                  className="w-full py-4 bg-sky-500 hover:bg-sky-600 text-white rounded-xl font-bold transition-all shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
                >
                  Enroll Now to Unlock Full Course <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md" onClick={() => !isPaying && setShowPaymentModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-md w-full relative z-10 shadow-2xl"
          >
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-sky-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Lock className="w-10 h-10 text-sky-400" />
              </div>
              <h3 className="text-2xl font-bold mb-2 text-white">Unlock Your Potential</h3>
              <p className="text-slate-400">
                Complete your payment via M-Pesa to start your journey in {program.title}. Payments are sent to 0113271756.
              </p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                <div className="text-sm text-slate-400 mb-1">Amount Due</div>
                <div className="text-2xl font-bold text-white">{program.price}</div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-400 ml-1">M-Pesa Phone Number</label>
                <input
                  type="tel"
                  placeholder="e.g. 0712345678"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                />
              </div>

              <div className="p-4 bg-slate-950/50 rounded-2xl border border-slate-800">
                <div className="text-sm text-slate-400 mb-1">Payment Method</div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center font-bold text-white">M</div>
                  <span className="font-bold text-white">M-Pesa Express</span>
                </div>
              </div>
            </div>

            <button
              onClick={processPayment}
              disabled={isPaying || !phoneNumber}
              className="w-full py-4 bg-sky-500 hover:bg-sky-600 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all shadow-lg shadow-sky-500/25 flex items-center justify-center gap-2"
            >
              {isPaying ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processing...
                </>
              ) : (
                'Pay with M-Pesa'
              )}
            </button>
            <button
              onClick={() => setShowPaymentModal(false)}
              disabled={isPaying}
              className="w-full py-4 text-slate-400 hover:text-white transition-colors mt-2 disabled:opacity-50"
            >
              Cancel
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
