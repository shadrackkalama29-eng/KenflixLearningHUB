import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { GraduationCap, ArrowRight, Chrome } from 'lucide-react';
import { auth, db, signInWithGoogle } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

export function Login() {
  const navigate = useNavigate();
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const user = await signInWithGoogle();

      // Check if user exists in Firestore
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);

      if (!userSnap.exists()) {
        // Create new user as student
        await setDoc(userRef, {
          id: user.uid,
          name: user.displayName || 'Anonymous',
          email: user.email,
          role: 'student',
          avatar: user.photoURL || ''
        });
        navigate('/programs');
      } else {
        const userData = userSnap.data();
        if (userData.role === 'admin') {
          navigate('/admin');
        } else {
          navigate('/programs');
        }
      }
    } catch (error) {
      console.error("Login failed", error);
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-bg px-4 py-12">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2 mb-8">
            <div className="bg-sky-500 p-2 rounded-xl">
              <GraduationCap className="text-white w-8 h-8" />
            </div>
            <span className="font-display font-bold text-2xl tracking-tight text-white">
              Kenflix <span className="text-sky-500">Hub</span>
            </span>
          </Link>
          <h2 className="text-3xl font-display font-bold text-white">Welcome Back</h2>
          <p className="mt-2 text-slate-400">Access your learning portal and community</p>
        </div>

        <div className="card-dark p-8 space-y-8">
          <div className="text-center space-y-4">
            <p className="text-sm text-slate-400">
              Sign in with your Google account to access your courses, track your progress, and join the community.
            </p>
            
            <button
              onClick={handleGoogleLogin}
              disabled={isLoggingIn}
              className="w-full flex items-center justify-center gap-3 py-4 bg-white text-slate-900 rounded-2xl font-bold hover:bg-slate-100 transition-all shadow-xl disabled:opacity-50"
            >
              {isLoggingIn ? (
                <div className="w-5 h-5 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin" />
              ) : (
                <Chrome className="w-6 h-6" />
              )}
              Continue with Google
            </button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-800"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-slate-900 px-4 text-slate-500 font-bold tracking-widest">Secure Login</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-3 text-slate-400 text-sm">
              <div className="w-1.5 h-1.5 bg-sky-500 rounded-full" />
              <span>Access to all enrolled programs</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400 text-sm">
              <div className="w-1.5 h-1.5 bg-sky-500 rounded-full" />
              <span>Participate in community discussions</span>
            </div>
            <div className="flex items-center gap-3 text-slate-400 text-sm">
              <div className="w-1.5 h-1.5 bg-sky-500 rounded-full" />
              <span>Track your learning milestones</span>
            </div>
          </div>
        </div>

        <p className="text-center text-sm text-slate-500">
          By signing in, you agree to our <Link to="/terms" className="text-sky-400 font-bold hover:underline">Terms</Link> and <Link to="/privacy" className="text-sky-400 font-bold hover:underline">Privacy Policy</Link>.
        </p>
      </div>
    </div>
  );
}
