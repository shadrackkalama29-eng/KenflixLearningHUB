import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send, MessageCircle } from 'lucide-react';

export function Contact() {
  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h1 className="text-4xl md:text-5xl font-display font-bold text-secondary">Get in Touch</h1>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Have questions about our programs or need support? We're here to help you on your learning journey.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            {[
              { icon: Mail, title: 'Email Us', value: 'hello@kenflixhub.com', desc: 'Our team will respond within 24 hours.' },
              { icon: Phone, title: 'Call Us', value: '+254 700 000 000', desc: 'Mon-Fri from 8am to 5pm.' },
              { icon: MapPin, title: 'Visit Us', value: 'Nairobi, Kenya', desc: '123 Digital Plaza, Westlands.' }
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm flex items-start gap-6">
                <div className="bg-primary/10 p-4 rounded-2xl text-primary">
                  <item.icon className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-display font-bold text-secondary">{item.title}</h4>
                  <p className="text-primary font-bold">{item.value}</p>
                  <p className="text-xs text-slate-500">{item.desc}</p>
                </div>
              </div>
            ))}

            <div className="bg-secondary p-8 rounded-3xl text-white space-y-6">
              <h3 className="text-xl font-display font-bold">Live Chat</h3>
              <p className="text-sm text-slate-300">Need immediate help? Chat with our support team right now.</p>
              <button className="w-full bg-accent text-white py-3 rounded-xl font-bold text-sm hover:bg-accent/90 transition-all flex items-center justify-center gap-2">
                <MessageCircle className="w-5 h-5" /> Start Chat
              </button>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white p-8 md:p-12 rounded-3xl border border-slate-100 shadow-xl">
              <form className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-secondary ml-1">First Name</label>
                  <input 
                    type="text" 
                    placeholder="John" 
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-secondary ml-1">Last Name</label>
                  <input 
                    type="text" 
                    placeholder="Doe" 
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none transition-all"
                  />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm font-bold text-secondary ml-1">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="john@example.com" 
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none transition-all"
                  />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm font-bold text-secondary ml-1">Subject</label>
                  <select className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none transition-all bg-white">
                    <option>General Inquiry</option>
                    <option>Program Enrollment</option>
                    <option>Technical Support</option>
                    <option>Partnership</option>
                  </select>
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-sm font-bold text-secondary ml-1">Message</label>
                  <textarea 
                    rows={6} 
                    placeholder="How can we help you?" 
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-primary outline-none transition-all resize-none"
                  ></textarea>
                </div>
                <div className="md:col-span-2">
                  <button className="w-full bg-primary text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
                    Send Message <Send className="w-5 h-5" />
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
