import { motion } from 'motion/react';
import { Users, BookOpen, CreditCard, ShieldCheck, Settings, BarChart, Search, MoreVertical } from 'lucide-react';

export function AdminPanel() {
  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-3xl font-display font-bold text-secondary">Admin Control Center</h1>
            <p className="text-slate-500">Global platform management and analytics.</p>
          </div>
          <div className="flex gap-3">
            <button className="bg-white border border-slate-200 text-secondary px-6 py-3 rounded-2xl font-bold text-sm hover:bg-slate-50 transition-all">
              Export Reports
            </button>
            <button className="bg-primary text-white px-6 py-3 rounded-2xl font-bold text-sm hover:bg-primary/90 transition-all shadow-lg shadow-primary/20">
              System Settings
            </button>
          </div>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {[
            { label: 'Total Revenue', value: '$45,280', icon: CreditCard, color: 'text-green-600', bg: 'bg-green-50' },
            { label: 'Total Users', value: '12,480', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'Course Completion', value: '78%', icon: ShieldCheck, color: 'text-purple-600', bg: 'bg-purple-50' },
            { label: 'Platform Growth', value: '+12.5%', icon: BarChart, color: 'text-orange-600', bg: 'bg-orange-50' }
          ].map((stat, idx) => (
            <div key={idx} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
              <div className={`${stat.bg} p-4 rounded-2xl`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider">{stat.label}</p>
                <p className="text-2xl font-display font-bold text-secondary">{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1 space-y-4">
            <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm space-y-1">
              {[
                { icon: BarChart, name: 'Analytics', active: true },
                { icon: Users, name: 'User Management', active: false },
                { icon: BookOpen, name: 'Course Catalog', active: false },
                { icon: CreditCard, name: 'Payments', active: false },
                { icon: ShieldCheck, name: 'Certificates', active: false },
                { icon: Settings, name: 'Platform Settings', active: false }
              ].map((item, idx) => (
                <button
                  key={idx}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                    item.active ? 'bg-primary text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  {item.name}
                </button>
              ))}
            </div>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-3 space-y-8">
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-display font-bold text-secondary">Recent Enrollments</h3>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input 
                    type="text" 
                    placeholder="Search users..." 
                    className="pl-10 pr-4 py-2 rounded-xl border border-slate-100 text-sm focus:ring-2 focus:ring-primary outline-none"
                  />
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-100">
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">User</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Program</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Date</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Amount</th>
                      <th className="pb-4 text-xs font-bold text-slate-400 uppercase tracking-wider"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {[
                      { name: 'Sarah Wilson', program: 'Graphic Design', date: 'Oct 12, 2023', amount: '$199' },
                      { name: 'James Miller', program: 'Web Design', date: 'Oct 11, 2023', amount: '$249' },
                      { name: 'Linda Garcia', program: 'AI Tools', date: 'Oct 11, 2023', amount: '$149' },
                      { name: 'Robert Taylor', program: 'Digital Marketing', date: 'Oct 10, 2023', amount: '$179' },
                      { name: 'Patricia Moore', program: 'Freelancing', date: 'Oct 10, 2023', amount: '$129' }
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 transition-colors">
                        <td className="py-4 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                            {row.name.charAt(0)}
                          </div>
                          <span className="text-sm font-bold text-secondary">{row.name}</span>
                        </td>
                        <td className="py-4 text-sm text-slate-600">{row.program}</td>
                        <td className="py-4 text-sm text-slate-500">{row.date}</td>
                        <td className="py-4 text-sm font-bold text-secondary">{row.amount}</td>
                        <td className="py-4 text-right">
                          <button className="text-slate-400 hover:text-primary transition-colors">
                            <MoreVertical className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <button className="w-full py-3 text-sm font-bold text-primary hover:bg-primary/5 rounded-xl transition-colors">
                View All Transactions
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
