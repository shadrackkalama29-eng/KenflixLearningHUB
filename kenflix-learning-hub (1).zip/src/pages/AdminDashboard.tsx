import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, BookOpen, DollarSign, TrendingUp, Search, Filter, MoreVertical, CheckCircle, XCircle, Clock, Shield, LogOut, Bell, ChevronRight, User as UserIcon } from 'lucide-react';
import { auth, db } from '../firebase';
import { collection, query, onSnapshot, orderBy, limit, doc, updateDoc, deleteDoc, getDoc } from 'firebase/firestore';
import { Enrollment, User } from '../types';
import { useNavigate } from 'react-router-dom';

export function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalEnrollments: 0,
    totalRevenue: 0,
    activeStudents: 0
  });
  const [recentEnrollments, setRecentEnrollments] = useState<Enrollment[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'enrollments'>('overview');
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged(async (user) => {
      if (!user) {
        navigate('/login');
        return;
      }
      
      // Verify admin role
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (!userDoc.exists() || userDoc.data().role !== 'admin') {
        navigate('/programs');
      }
    });

    const unsubscribeEnrollments = onSnapshot(collection(db, 'enrollments'), (snapshot) => {
      const data = snapshot.docs.map(doc => doc.data() as Enrollment);
      setRecentEnrollments(data.slice(0, 5));
      setStats(prev => ({
        ...prev,
        totalEnrollments: data.length,
        totalRevenue: data.length * 1500, // Mock revenue
        activeStudents: data.filter(e => e.status === 'active').length
      }));
    });

    const unsubscribeUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => doc.data() as User));
      setStats(prev => ({ ...prev, totalUsers: snapshot.docs.length }));
    });

    return () => {
      unsubscribeAuth();
      unsubscribeEnrollments();
      unsubscribeUsers();
    };
  }, [navigate]);

  return (
    <div className="min-h-screen bg-dark-bg pt-24 pb-20 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-display font-bold text-white">Admin Console</h1>
            <div className="flex items-center gap-4 mt-4">
              {['overview', 'users', 'enrollments'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab as any)}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all uppercase tracking-widest ${
                    activeTab === tab 
                      ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/20' 
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="bg-slate-800 border border-slate-700 px-4 py-2 rounded-xl text-sm font-bold text-white hover:bg-slate-700 transition-all flex items-center gap-2">
              <Shield className="w-4 h-4" /> Security Logs
            </button>
            <button 
              onClick={() => auth.signOut()}
              className="bg-rose-500/10 border border-rose-500/20 px-4 py-2 rounded-xl text-sm font-bold text-rose-400 hover:bg-rose-500/20 transition-all flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>

        {activeTab === 'overview' && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {[
                { label: 'Total Students', value: stats.totalUsers, icon: Users, color: 'sky' },
                { label: 'Total Enrollments', value: stats.totalEnrollments, icon: BookOpen, color: 'emerald' },
                { label: 'Total Revenue', value: `KSh ${stats.totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'orange' },
                { label: 'Active Learners', value: stats.activeStudents, icon: TrendingUp, color: 'violet' }
              ].map((stat, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="card-dark p-6 space-y-4"
                >
                  <div className={`bg-${stat.color}-500/10 w-12 h-12 rounded-2xl flex items-center justify-center`}>
                    <stat.icon className={`w-6 h-6 text-${stat.color}-400`} />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
                    <h3 className="text-2xl font-display font-bold text-white mt-1">{stat.value}</h3>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Recent Enrollments */}
              <div className="lg:col-span-2 space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-display font-bold text-white">Recent Enrollments</h2>
                  <button 
                    onClick={() => setActiveTab('enrollments')}
                    className="text-sky-400 text-xs font-bold uppercase tracking-widest hover:text-sky-300"
                  >
                    View All
                  </button>
                </div>
                <div className="card-dark overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-900/50 border-b border-slate-800">
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Student</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Course</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Date</th>
                          <th className="px-6 py-4"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {recentEnrollments.map((enrollment, idx) => (
                          <tr key={idx} className="hover:bg-slate-800/30 transition-colors group">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-[10px] font-bold text-sky-400">
                                  {enrollment.userId.slice(0, 2).toUpperCase()}
                                </div>
                                <span className="text-sm font-bold text-white">Student #{enrollment.userId.slice(0, 4)}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-sm text-slate-400">{enrollment.programId}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                                enrollment.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-orange-500/10 text-orange-400'
                              }`}>
                                {enrollment.status === 'active' ? <CheckCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                                {enrollment.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-500">
                              {new Date(enrollment.lastPaymentDate).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button className="p-2 text-slate-600 hover:text-white transition-colors">
                                <MoreVertical className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Quick Actions & System Health */}
              <div className="space-y-8">
                <div className="space-y-6">
                  <h2 className="text-xl font-display font-bold text-white">Quick Actions</h2>
                  <div className="grid grid-cols-1 gap-3">
                    {[
                      { label: 'Add New Course', icon: BookOpen, color: 'sky' },
                      { label: 'Broadcast Message', icon: Bell, color: 'violet' },
                      { label: 'Export Reports', icon: TrendingUp, color: 'emerald' },
                      { label: 'Manage Admins', icon: Shield, color: 'orange' }
                    ].map((action, idx) => (
                      <button
                        key={idx}
                        className="flex items-center justify-between p-4 bg-slate-900 border border-slate-800 rounded-2xl hover:border-sky-500/50 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className={`bg-${action.color}-500/10 p-2 rounded-lg`}>
                            <action.icon className={`w-4 h-4 text-${action.color}-400`} />
                          </div>
                          <span className="text-sm font-bold text-white">{action.label}</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-slate-700 group-hover:text-sky-500 transition-transform group-hover:translate-x-1" />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="card-dark p-6 space-y-4">
                  <h3 className="text-sm font-bold text-white uppercase tracking-widest">System Health</h3>
                  <div className="space-y-4">
                    {[
                      { label: 'Database', status: 'Healthy', color: 'emerald' },
                      { label: 'Auth Service', status: 'Healthy', color: 'emerald' },
                      { label: 'Payment Gateway', status: 'Maintenance', color: 'orange' }
                    ].map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between">
                        <span className="text-xs text-slate-400">{item.label}</span>
                        <span className={`text-[10px] font-bold uppercase tracking-widest text-${item.color}-400 flex items-center gap-1.5`}>
                          <div className={`w-1.5 h-1.5 rounded-full bg-${item.color}-400`} />
                          {item.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-display font-bold text-white">User Management</h2>
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input 
                    type="text" 
                    placeholder="Search users..." 
                    className="bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:ring-2 focus:ring-sky-500 outline-none transition-all"
                  />
                </div>
                <button className="bg-slate-800 p-2 rounded-xl text-slate-400 hover:text-white transition-colors">
                  <Filter className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="card-dark overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-900/50 border-b border-slate-800">
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">User</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Email</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Role</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Joined</th>
                      <th className="px-6 py-4"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {users.map((user) => (
                      <tr key={user.uid} className="hover:bg-slate-800/30 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            {user.photoURL ? (
                              <img src={user.photoURL} alt={user.displayName} className="w-8 h-8 rounded-lg object-cover" />
                            ) : (
                              <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-[10px] font-bold text-sky-400">
                                <UserIcon className="w-4 h-4" />
                              </div>
                            )}
                            <span className="text-sm font-bold text-white">{user.displayName}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-400">{user.email}</td>
                        <td className="px-6 py-4">
                          <select 
                            value={user.role}
                            onChange={async (e) => {
                              await updateDoc(doc(db, 'users', user.uid), { role: e.target.value });
                            }}
                            className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-sky-400 outline-none focus:ring-1 focus:ring-sky-500"
                          >
                            <option value="student">Student</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-500">
                          {new Date(user.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button 
                            onClick={async () => {
                              if (confirm('Are you sure you want to delete this user?')) {
                                await deleteDoc(doc(db, 'users', user.uid));
                              }
                            }}
                            className="p-2 text-slate-600 hover:text-rose-500 transition-colors"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'enrollments' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-display font-bold text-white">Enrollment History</h2>
            <div className="card-dark overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-900/50 border-b border-slate-800">
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Student ID</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Program</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Progress</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Last Payment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {recentEnrollments.map((enrollment, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/30 transition-colors group">
                        <td className="px-6 py-4 text-sm text-slate-300 font-mono">{enrollment.userId}</td>
                        <td className="px-6 py-4 text-sm text-white font-bold">{enrollment.programId}</td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                            enrollment.status === 'active' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-orange-500/10 text-orange-400'
                          }`}>
                            {enrollment.status}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden max-w-[100px]">
                            <div className="bg-sky-500 h-full" style={{ width: `${enrollment.progress}%` }} />
                          </div>
                          <span className="text-[10px] text-slate-500 mt-1 block">{enrollment.progress}%</span>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-500">
                          {new Date(enrollment.lastPaymentDate).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
