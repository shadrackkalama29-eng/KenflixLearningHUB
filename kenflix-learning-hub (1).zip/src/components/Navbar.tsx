import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, ArrowRight, LogOut, User as UserIcon, GraduationCap, LayoutDashboard, ShieldCheck } from 'lucide-react';
import { cn } from '../lib/utils';
import { auth, signInWithGoogle, logout, db } from '../firebase';
import { doc, getDoc } from 'firebase/firestore';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState(auth.currentUser);
  const [role, setRole] = useState<string | null>(null);
  const location = useLocation();

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (u) => {
      setUser(u);
      if (u) {
        const userDoc = await getDoc(doc(db, 'users', u.uid));
        if (userDoc.exists()) {
          setRole(userDoc.data().role);
        }
      } else {
        setRole(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const navLinks = [
    { name: 'PROGRAMMES', href: '/programs', hasDropdown: true },
    { name: 'WOMEN & TECH', href: '/women-tech' },
    { name: 'COMMUNITY', href: '/community', hasDropdown: true },
    { name: 'ABOUT KENFLIX', href: '/about', hasDropdown: true },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-dark-bg/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-sky-500 p-1.5 rounded-lg">
              <GraduationCap className="text-white w-6 h-6" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-white">
              Kenflix <span className="text-sky-500">Hub</span>
            </span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <div key={link.name} className="flex items-center gap-1 group cursor-pointer">
                <Link
                  to={link.href}
                  className={cn(
                    "text-[13px] font-bold transition-colors hover:text-sky-400 tracking-wide",
                    location.pathname === link.href ? "text-sky-400" : "text-slate-400"
                  )}
                >
                  {link.name}
                </Link>
                {link.hasDropdown && <ChevronDown className="w-4 h-4 text-slate-600 group-hover:text-sky-400 transition-colors" />}
              </div>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                {role === 'admin' && (
                  <Link
                    to="/admin"
                    className="flex items-center gap-2 text-orange-400 hover:text-orange-300 transition-colors text-xs font-bold uppercase tracking-widest"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Admin
                  </Link>
                )}
                <Link
                  to="/dashboard"
                  className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 px-4 py-2 rounded-full border border-slate-700 transition-all"
                >
                  <LayoutDashboard className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-bold text-white">Dashboard</span>
                </Link>
                <div className="flex items-center gap-2 bg-slate-900/50 px-3 py-2 rounded-full border border-slate-800">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || ''} className="w-6 h-6 rounded-full" />
                  ) : (
                    <UserIcon className="w-4 h-4 text-sky-400" />
                  )}
                  <span className="text-xs font-bold text-slate-300">{user.displayName?.split(' ')[0]}</span>
                </div>
                <button
                  onClick={logout}
                  className="p-2 text-slate-500 hover:text-orange-500 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="flex items-center gap-2 border border-sky-500 text-sky-400 px-6 py-2.5 rounded-full text-[13px] font-bold hover:bg-sky-500 hover:text-white transition-all"
              >
                Login to Portal <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-400 hover:text-sky-400 p-2"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 py-4 px-4 space-y-4">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.href}
              onClick={() => setIsOpen(false)}
              className="block text-sm font-bold text-slate-400 hover:text-sky-400"
            >
              {link.name}
            </Link>
          ))}
          {user && (
            <>
              <Link
                to="/dashboard"
                onClick={() => setIsOpen(false)}
                className="flex items-center gap-2 text-sm font-bold text-sky-400"
              >
                <LayoutDashboard className="w-4 h-4" />
                Student Dashboard
              </Link>
              {role === 'admin' && (
                <Link
                  to="/admin"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-2 text-sm font-bold text-orange-400"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Admin Panel
                </Link>
              )}
            </>
          )}
          <div className="pt-4 border-t border-slate-800 flex flex-col gap-3">
            {user ? (
              <button
                onClick={() => { logout(); setIsOpen(false); }}
                className="flex items-center justify-center gap-2 bg-slate-800 text-white px-6 py-2.5 rounded-full text-sm font-bold"
              >
                Logout <LogOut className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => { signInWithGoogle(); setIsOpen(false); }}
                className="flex items-center justify-center gap-2 border border-sky-500 text-sky-400 px-6 py-2.5 rounded-full text-sm font-bold"
              >
                Login to Portal <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
