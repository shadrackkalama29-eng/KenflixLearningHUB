import { Link } from 'react-router-dom';
import { GraduationCap, Facebook, Twitter, Instagram, Linkedin, Mail } from 'lucide-react';
import { PROGRAMS } from '../constants';

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-8 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-sky-500 p-1.5 rounded-lg">
                <GraduationCap className="text-white w-6 h-6" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-white">
                Kenflix <span className="text-sky-500">Hub</span>
              </span>
            </Link>
            <p className="text-sm leading-relaxed">
              Equipping the next generation of digital leaders across Africa with practical, industry-focused skills.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-sky-500 transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="hover:text-sky-500 transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="hover:text-sky-500 transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="hover:text-sky-500 transition-colors"><Linkedin className="w-5 h-5" /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-6">Our Programs</h4>
            <ul className="space-y-4 text-sm">
              {PROGRAMS.map(program => (
                <li key={program.id}>
                  <Link to={`/programs/${program.id}`} className="hover:text-sky-500 transition-colors">
                    {program.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-6">Support</h4>
            <ul className="space-y-4 text-sm">
              <li><Link to="/contact" className="hover:text-sky-500 transition-colors">Contact Us</Link></li>
              <li><Link to="/privacy" className="hover:text-sky-500 transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-sky-500 transition-colors">Terms of Service</Link></li>
              <li><Link to="/faq" className="hover:text-sky-500 transition-colors">FAQs</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-display font-semibold mb-6">Newsletter</h4>
            <p className="text-sm mb-4">Stay updated with our latest programs and events.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-sm w-full focus:ring-2 focus:ring-sky-500 outline-none"
              />
              <button className="bg-sky-500 hover:bg-sky-600 text-white p-2 rounded-lg transition-colors">
                <Mail className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-slate-900 pt-8 text-center text-xs">
          <p>© {new Date().getFullYear()} Kenflix Learning Hub. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
