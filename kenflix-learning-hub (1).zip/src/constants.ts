import { Program } from './types';

export const PROGRAMS: Program[] = [
  {
    id: '1',
    title: 'Software Engineering',
    description: 'Master full-stack development and computer science fundamentals to build scalable applications.',
    duration: '12 Months',
    level: 'Beginner to Advanced',
    category: 'Tech',
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80',
    price: '$5/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'Julien Barbier',
      role: 'Software Engineering Lead',
      avatar: 'https://i.pravatar.cc/150?u=julien'
    },
    curriculum: [
      { week: 1, title: 'Low-level Programming', content: 'Master C programming, memory management, and data structures.' },
      { week: 2, title: 'Higher-level Programming', content: 'Python, object-oriented programming, and scripting.' },
      { week: 3, title: 'System Engineering & DevOps', content: 'Linux, shell, networking, and server management.' },
      { week: 4, title: 'Full-Stack Web Development', content: 'JavaScript, React, Node.js, and databases.' }
    ],
    readingMaterials: [
      { title: 'The C Programming Language', url: 'https://example.com/c-book.pdf', type: 'pdf', description: 'Comprehensive guide to C programming.' },
      { title: 'Python for Beginners', url: 'https://example.com/python-video', type: 'video', description: 'Introductory video for Python.' }
    ],
    demoMaterials: [
      { title: 'Intro to Software Engineering', url: 'https://example.com/intro-se.pdf', type: 'pdf', description: 'A free preview of the course.' }
    ]
  },
  {
    id: '2',
    title: 'Data Science & AI',
    description: 'Learn to extract insights from data and build machine learning models to solve complex problems.',
    duration: '6 Months',
    level: 'Intermediate',
    category: 'Data',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    price: '$8/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'Dr. Aisha Kamau',
      role: 'Senior Data Scientist',
      avatar: 'https://i.pravatar.cc/150?u=aisha'
    },
    curriculum: [
      { week: 1, title: 'Probability & Statistics', content: 'Foundations of data analysis.' },
      { week: 2, title: 'Data Wrangling with Python', content: 'Cleaning and preparing data for analysis.' },
      { week: 3, title: 'Machine Learning Models', content: 'Supervised and unsupervised learning.' },
      { week: 4, title: 'Data Visualization', content: 'Communicating insights effectively.' }
    ],
    readingMaterials: [
      { title: 'Hands-On Machine Learning', url: 'https://example.com/ml-book.pdf', type: 'pdf', description: 'Practical guide to ML.' },
      { title: 'Data Science Handbook', url: 'https://example.com/ds-article', type: 'article', description: 'Essential data science concepts.' }
    ],
    demoMaterials: [
      { title: 'Data Science Overview', url: 'https://example.com/ds-intro.pdf', type: 'pdf', description: 'Free introduction to data science.' }
    ]
  },
  {
    id: '3',
    title: 'Digital Marketing Mastery',
    description: 'Master SEO, SEM, and social media marketing to grow businesses in the digital age.',
    duration: '3 Months',
    level: 'Beginner',
    category: 'Marketing',
    image: 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?auto=format&fit=crop&w=800&q=80',
    price: '$5/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'Sarah Chen',
      role: 'Marketing Strategist',
      avatar: 'https://i.pravatar.cc/150?u=sarah'
    },
    curriculum: [
      { week: 1, title: 'SEO Fundamentals', content: 'Optimizing content for search engines.' },
      { week: 2, title: 'Social Media Strategy', content: 'Building brand presence on social platforms.' },
      { week: 3, title: 'Paid Advertising', content: 'Google Ads and Facebook Ads management.' },
      { week: 4, title: 'Analytics & Reporting', content: 'Measuring marketing performance.' }
    ],
    readingMaterials: [
      { title: 'SEO 2024 Guide', url: 'https://example.com/seo-pdf', type: 'pdf', description: 'Latest SEO strategies.' },
      { title: 'Social Media Trends', url: 'https://example.com/sm-video', type: 'video', description: 'Trends for the current year.' }
    ],
    demoMaterials: [
      { title: 'Marketing Basics', url: 'https://example.com/marketing-intro.pdf', type: 'pdf', description: 'Free marketing overview.' }
    ]
  },
  {
    id: '4',
    title: 'UI/UX Design Professional',
    description: 'Design beautiful and functional user interfaces and experiences for web and mobile.',
    duration: '4 Months',
    level: 'Beginner',
    category: 'Design',
    image: 'https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?auto=format&fit=crop&w=800&q=80',
    price: '$7/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'David Miller',
      role: 'Product Designer',
      avatar: 'https://i.pravatar.cc/150?u=david'
    },
    curriculum: [
      { week: 1, title: 'Design Principles', content: 'Color theory, typography, and layout.' },
      { week: 2, title: 'User Research', content: 'Understanding user needs and behaviors.' },
      { week: 3, title: 'Prototyping with Figma', content: 'Building interactive design prototypes.' },
      { week: 4, title: 'Usability Testing', content: 'Iterating designs based on user feedback.' }
    ],
    readingMaterials: [
      { title: 'Don\'t Make Me Think', url: 'https://example.com/ux-book.pdf', type: 'pdf' },
      { title: 'Figma Mastery Course', url: 'https://example.com/figma-video', type: 'video' }
    ]
  },
  {
    id: '5',
    title: 'Freelancing & Business',
    description: 'Learn how to build a successful freelancing career and manage your own business.',
    duration: '2 Months',
    level: 'Beginner',
    category: 'Business',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80',
    price: '$5/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'James Wilson',
      role: 'Business Consultant',
      avatar: 'https://i.pravatar.cc/150?u=james'
    },
    curriculum: [
      { week: 1, title: 'Finding Clients', content: 'Strategies for landing your first gig.' },
      { week: 2, title: 'Pricing & Proposals', content: 'How to value your work and win projects.' },
      { week: 3, title: 'Project Management', content: 'Tools and techniques for efficient delivery.' },
      { week: 4, title: 'Financial Management', content: 'Taxes, invoicing, and budgeting for freelancers.' }
    ],
    readingMaterials: [
      { title: 'The Freelance Manifesto', url: 'https://example.com/freelance-pdf', type: 'pdf' },
      { title: 'Business Model Canvas', url: 'https://example.com/business-article', type: 'article' }
    ]
  },
  {
    id: '6',
    title: 'Graphics Design Mastery',
    description: 'Master visual communication through professional design tools and principles.',
    duration: '4 Months',
    level: 'Beginner',
    category: 'Design',
    image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=800&q=80',
    price: '$6/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'Alex Rivera',
      role: 'Senior Graphic Designer',
      avatar: 'https://i.pravatar.cc/150?u=alex'
    },
    curriculum: [
      { week: 1, title: 'Adobe Illustrator', content: 'Vector graphics and illustration techniques.' },
      { week: 2, title: 'Adobe Photoshop', content: 'Image editing and composition.' },
      { week: 3, title: 'Branding & Identity', content: 'Creating cohesive visual systems.' },
      { week: 4, title: 'Print & Digital Layout', content: 'Designing for various mediums.' }
    ],
    readingMaterials: [
      { title: 'Graphic Design School', url: 'https://example.com/gd-book.pdf', type: 'pdf' },
      { title: 'Color Theory Basics', url: 'https://example.com/color-video', type: 'video' }
    ]
  },
  {
    id: '7',
    title: 'Modern Web Design',
    description: 'Create stunning, responsive websites using the latest design trends and technologies.',
    duration: '3 Months',
    level: 'Beginner',
    category: 'Design',
    image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&w=800&q=80',
    price: '$5/month',
    startDate: 'Enroll Now',
    instructor: {
      name: 'Maya Patel',
      role: 'Web Designer',
      avatar: 'https://i.pravatar.cc/150?u=maya'
    },
    curriculum: [
      { week: 1, title: 'HTML & CSS Layouts', content: 'Building the foundation of the web.' },
      { week: 2, title: 'Responsive Design', content: 'Ensuring websites work on all devices.' },
      { week: 3, title: 'Web Typography', content: 'Choosing and using fonts for the web.' },
      { week: 4, title: 'CMS & No-Code Tools', content: 'Building with Webflow and WordPress.' }
    ],
    readingMaterials: [
      { title: 'Web Design Trends 2024', url: 'https://example.com/web-trends.pdf', type: 'pdf' },
      { title: 'Responsive Design Guide', url: 'https://example.com/responsive-video', type: 'video' }
    ]
  }
];
