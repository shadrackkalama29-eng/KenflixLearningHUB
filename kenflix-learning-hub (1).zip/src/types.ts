export interface ReadingMaterial {
  title: string;
  url: string;
  type: 'pdf' | 'video' | 'article';
  description?: string;
}

export interface Program {
  id: string;
  title: string;
  description: string;
  duration: string;
  level: string;
  category: string;
  image: string;
  price: string;
  startDate: string;
  instructor: {
    name: string;
    role: string;
    avatar: string;
  };
  curriculum: {
    week: number;
    title: string;
    content: string;
  }[];
  readingMaterials?: ReadingMaterial[];
  demoMaterials?: ReadingMaterial[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'instructor' | 'admin';
  avatar?: string;
}

export interface Enrollment {
  id: string;
  userId: string;
  programId: string;
  status: 'active' | 'locked' | 'completed';
  progress: number;
  completedModules: number[];
  dueDate: string;
  lastPaymentDate: string;
}

export interface Payment {
  id: string;
  userId: string;
  enrollmentId: string;
  amount: number;
  method: 'mpesa';
  transactionId: string;
  timestamp: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  content: string;
  createdAt: string;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  image?: string;
  likes: string[]; // array of userIds
  comments: Comment[];
  createdAt: string;
}
